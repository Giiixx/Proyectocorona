<?php


date_default_timezone_set("America/Bogota");
$fecha_actual = date("y m 5");
echo  $fecha_actual;


?>
